package text.editor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JMenuBar;
import javax.swing.JTextArea;
import javax.swing.ImageIcon;
/**
 *
 * @author Abid
 */
public class Grid extends JFrame{
    int fileToOpen;
    int fileToSave;
    JFileChooser fileOpen;
    JFileChooser fileSave;

    public void openFile(){
        JFileChooser open = new JFileChooser();
        int option = open.showOpenDialog(this);
        fileToOpen = option;
        fileOpen = open;
}
       public void saveFile(){
        JFileChooser save = new JFileChooser();
        int option = save.showOpenDialog(this);
        fileToSave = option;
        fileSave = save;
       }
Grid(){
    super("Text Editor");
    
            JMenuBar menuBar = new JMenuBar();
            final JTextArea textArea = new JTextArea();
            setJMenuBar(menuBar);
            JMenu file = new JMenu("File");
            menuBar.add(file);
            JMenuItem onNew = new JMenuItem("New File", new ImageIcon(getClass().getResource("Images/new.png")));
            JMenuItem onOpen = new JMenuItem("Open File", new ImageIcon(getClass().getResource("Images/open.png")));
            JMenuItem onSave = new JMenuItem("Save", new ImageIcon(getClass().getResource("Images/save.png")));
            JMenuItem onExit = new JMenuItem("Exit");
            file.add(onNew);
            file.add(onOpen);
            file.add(onSave);
            file.add(onExit);
            getContentPane().add(textArea);
            onNew.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    textArea.setText("");
                }
            });
            onOpen.addActionListener(new ActionListener(){
                public void actionPerformed(ActionEvent e){
                    openFile();
                    if (fileToOpen == JFileChooser.APPROVE_OPTION){
                        textArea.setText("");
                        try{
                            Scanner scan = new Scanner(new FileReader(fileOpen.getSelectedFile().getPath()));
                            while (scan.hasNext())
                                textArea.append(scan.nextLine());
                        } catch (Exception ex){
                            System.out.println(ex.getMessage());
                        }
                    }
                }
            });
            onSave.addActionListener(new ActionListener(){
                
                public void actionPerformed(ActionEvent e){
                    saveFile();
                    if (fileToSave == JFileChooser.APPROVE_OPTION){
                        try {
                            
                            BufferedWriter out = new BufferedWriter(new FileWriter(fileSave.getSelectedFile().getPath()));
                            out.write(textArea.getText());
                            out.close();
                        }
                        catch (IOException ex) {
                            System.out.println(ex.getMessage());
                        }
                    }
                }
            });
onExit.addActionListener(new ActionListener(){
    public void actionPerformed(ActionEvent e){
    System.exit(0);
}
        });
        }
}

